import { NgModule } from '@angular/core';
import { Route, RouterModule, Routes, UrlSerializer } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { PostAttiviComponent } from './post-attivi/post-attivi.component';
import { PostDetailsComponent } from './post-details/post-details.component';
import { PostInattiviComponent } from './post-inattivi/post-inattivi.component';
import { PostComponent } from './post/post.component';
import { UsersComponent } from './users/users.component';
import { User } from './user';
import { getUsers } from './users.service';
import { UsersDetailsComponent } from './user-details/user-details.component';


const routes: Route[] = [
  {
    path: "",
    component: HomeComponent
  },
  {
    path: "post",
    component: PostComponent
  },

  {
    path: "post/attivi",
    component: PostAttiviComponent
  },
  {
    path: "post/inattivi",
    component: PostInattiviComponent
  },

  {
    path: "post-attivi/:id",
    component: PostDetailsComponent
  },

  {
    path: "post-inattivi/:id",
    component: PostDetailsComponent
  },
  {
    path: "post/users",
    component: UsersComponent,
    children: [
      {
        path: ":id",
        component: UsersDetailsComponent
      }
    ]
  }
]

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
