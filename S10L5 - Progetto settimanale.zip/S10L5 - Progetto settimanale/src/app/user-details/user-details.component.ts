import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { User } from '../user';
import { getUsers } from '../users.service';
@Component({
  selector: 'app-users-details',
  templateUrl: './user-details.component.html',
  styleUrls: ['./user-details.component.scss']
})
export class UsersDetailsComponent implements OnInit {

  u: User | undefined

  constructor(private ar: ActivatedRoute) {
  }

  ngOnInit(): void {
    let x = this.ar.snapshot.params["id"];
    getUsers().then((users: User[]) => {
      this.u = users.find((element) => {
        if(x == element.id) {

          return true;
        } else {
          return false;
          let error = document.getElementById('errore') as HTMLElement;
           error.innerHTML = "L'utente non esiste!";
        }
      })
    })
  }

}
